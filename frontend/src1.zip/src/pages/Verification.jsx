import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useUser } from "../context/UserContext";
import { api } from "../services/api";
import "../styles/Verification.css";

// ============================================================
// MAX ID DOCUMENT FILE SIZE (5 MB)
// ============================================================

const MAX_ID_FILE_SIZE = 5 * 1024 * 1024;

export default function Verification() {
  const { user, updateUser } = useUser();
  const navigate = useNavigate();
  const location = useLocation();

  // The domain the candidate picked on the previous screen is
  // passed through router state (NOT stored in context, since
  // we don't want to persist captured images to localStorage).
  const domain = location.state?.domain || null;

  // ============================================================
  // REFS
  // ============================================================

  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);

  // ============================================================
  // CAMERA STATE
  // ============================================================

  const [cameraStatus, setCameraStatus] = useState("idle");
  // idle | requesting | streaming | denied | unsupported | error

  const [cameraError, setCameraError] = useState("");

  const [photoDataUrl, setPhotoDataUrl] = useState(null);

  // ============================================================
  // ID DOCUMENT STATE
  // ============================================================

  const [idFile, setIdFile] = useState(null);
  const [idPreviewUrl, setIdPreviewUrl] = useState(null);
  const [idError, setIdError] = useState("");

  // ============================================================
  // START-EXAM STATE
  // ============================================================

  const [starting, setStarting] = useState(false);
  const [startError, setStartError] = useState("");

  // ============================================================
  // GUARD — NO DOMAIN SELECTED
  // ============================================================

  useEffect(() => {
    if (!user?.token) {
      navigate("/", { replace: true });
      return;
    }

    if (!domain?._id) {
      navigate("/domains", { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.token, domain]);

  // ============================================================
  // START CAMERA
  // ============================================================

  async function startCamera() {
    setCameraError("");

    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraStatus("unsupported");
      return;
    }

    try {
      setCameraStatus("requesting");

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" },
        audio: false,
      });

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      setCameraStatus("streaming");
    } catch (err) {
      console.error("Camera access error:", err);

      if (
        err?.name === "NotAllowedError" ||
        err?.name === "PermissionDeniedError"
      ) {
        setCameraStatus("denied");
      } else {
        setCameraStatus("error");
        setCameraError(
          err?.message || "Unable to access your camera."
        );
      }
    }
  }

  // ============================================================
  // STOP CAMERA
  // ============================================================

  function stopCamera() {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  }

  // ============================================================
  // START CAMERA ON MOUNT / STOP ON UNMOUNT
  // ============================================================

  useEffect(() => {
    if (domain?._id) {
      startCamera();
    }

    return () => {
      stopCamera();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [domain]);

  // ============================================================
  // CAPTURE PHOTO
  // ============================================================

  function capturePhoto() {
    const video = videoRef.current;
    const canvas = canvasRef.current;

    if (!video || !canvas) {
      return;
    }

    const width = video.videoWidth || 480;
    const height = video.videoHeight || 360;

    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, width, height);

    const dataUrl = canvas.toDataURL("image/jpeg", 0.9);

    setPhotoDataUrl(dataUrl);

    // Freeze the frame — stop the live stream until retake.
    stopCamera();
  }

  // ============================================================
  // RETAKE PHOTO
  // ============================================================

  function retakePhoto() {
    setPhotoDataUrl(null);
    startCamera();
  }

  // ============================================================
  // HANDLE ID FILE SELECT
  // ============================================================

  function handleIdFileChange(e) {
    const file = e.target.files?.[0];

    setIdError("");
    setIdFile(null);
    setIdPreviewUrl(null);

    if (!file) {
      return;
    }

    const allowedTypes = [
      "image/jpeg",
      "image/png",
      "image/webp",
      "application/pdf",
    ];

    if (!allowedTypes.includes(file.type)) {
      setIdError(
        "Please upload a JPG, PNG, or PDF file of your Aadhar or PAN card."
      );
      return;
    }

    if (file.size > MAX_ID_FILE_SIZE) {
      setIdError("File is too large. Maximum size is 5 MB.");
      return;
    }

    setIdFile(file);

    if (file.type !== "application/pdf") {
      const reader = new FileReader();

      reader.onload = () => {
        setIdPreviewUrl(reader.result);
      };

      reader.readAsDataURL(file);
    }
  }

  function removeIdFile() {
    setIdFile(null);
    setIdPreviewUrl(null);
    setIdError("");
  }

  // ============================================================
  // START ASSESSMENT
  // ============================================================
  //
  // Mirrors the exam-start logic that previously lived directly
  // on the domain-selection screen. Moved here so the candidate
  // completes identity verification BEFORE the server-side exam
  // timer starts.
  // ============================================================

  async function handleStartAssessment() {
    if (starting || !photoDataUrl || !idFile || !domain?._id) {
      return;
    }

    try {
      setStarting(true);
      setStartError("");

      const exam = await api.startExam(domain._id, user.token);

      if (
        !exam?.success ||
        !exam?.examId ||
        !Array.isArray(exam.questions) ||
        !exam.startTime ||
        !exam.durationMinutes
      ) {
        throw new Error(
          exam?.message || "Invalid exam response from server."
        );
      }

      if (exam.questions.length === 0) {
        throw new Error(
          "No questions are available for this assessment."
        );
      }

      const startTimeMs = new Date(exam.startTime).getTime();

      if (Number.isNaN(startTimeMs)) {
        throw new Error(
          "Invalid exam start time received from server."
        );
      }

      const durationMinutes = Number(exam.durationMinutes);

      if (!durationMinutes || durationMinutes <= 0) {
        throw new Error(
          "Invalid exam duration received from server."
        );
      }

      const testEndTime =
        startTimeMs + durationMinutes * 60 * 1000;

      const totalMarks = exam.questions.reduce(
        (total, question) => total + Number(question?.marks || 0),
        0
      );

      updateUser({
        token: user.token,

        domain: domain._id,
        domainId: domain._id,
        selectedDomain: domain,

        examId: exam.examId,
        examStatus: exam.status || "in_progress",

        questions: exam.questions,

        durationMinutes,
        startTime: exam.startTime,
        testEndTime,

        score: 0,
        totalMarks,

        autoSubmitted: false,
        answers: [],
      });

      navigate("/quiz", { replace: true });
    } catch (err) {
      console.error("Start exam error:", err);

      setStartError(
        err?.message || "Unable to start the assessment."
      );
    } finally {
      setStarting(false);
    }
  }

  // ============================================================
  // GUARD RENDER
  // ============================================================

  if (!user?.token || !domain?._id) {
    return null;
  }

  const readyToStart = Boolean(photoDataUrl && idFile);

  // ============================================================
  // UI
  // ============================================================

  return (
    <div className="assessment-card verify-card">
      <p className="eyebrow">Identity verification</p>

      <h1>Verify it's really you</h1>

      <p className="subtitle">
        Before starting the <strong>{domain.name}</strong> assessment,
        take a quick photo and upload a government ID (Aadhar or PAN
        card). This helps us confirm your identity.
      </p>

      {/* ========================================================
          STEP 1 — CAMERA PHOTO
      ======================================================== */}

      <div className="verify-section">
        <h2 className="verify-section-title">
          <span className="verify-step-num">1</span>
          Take a photo
        </h2>

        <div className="verify-camera-box">
          {!photoDataUrl && cameraStatus === "streaming" && (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="verify-video"
            />
          )}

          {!photoDataUrl && cameraStatus === "requesting" && (
            <p className="loading-text">Requesting camera access...</p>
          )}

          {!photoDataUrl && cameraStatus === "denied" && (
            <p className="form-error">
              Camera access was denied. Please allow camera permission
              in your browser settings and refresh this page.
            </p>
          )}

          {!photoDataUrl && cameraStatus === "unsupported" && (
            <p className="form-error">
              Your browser does not support camera access. Please try a
              different browser.
            </p>
          )}

          {!photoDataUrl && cameraStatus === "error" && (
            <p className="form-error">
              {cameraError || "Unable to access your camera."}
            </p>
          )}

          {photoDataUrl && (
            <img
              src={photoDataUrl}
              alt="Captured candidate"
              className="verify-photo-preview"
            />
          )}
        </div>

        <canvas ref={canvasRef} style={{ display: "none" }} />

        <div className="verify-camera-actions">
          {!photoDataUrl && cameraStatus === "streaming" && (
            <button
              type="button"
              className="btn-primary"
              onClick={capturePhoto}
            >
              Capture photo
            </button>
          )}

          {!photoDataUrl &&
            (cameraStatus === "denied" ||
              cameraStatus === "error" ||
              cameraStatus === "unsupported") && (
              <button
                type="button"
                className="btn-secondary"
                onClick={startCamera}
              >
                Try again
              </button>
            )}

          {photoDataUrl && (
            <button
              type="button"
              className="btn-secondary"
              onClick={retakePhoto}
            >
              Retake photo
            </button>
          )}
        </div>
      </div>

      {/* ========================================================
          STEP 2 — ID DOCUMENT UPLOAD
      ======================================================== */}

      <div className="verify-section">
        <h2 className="verify-section-title">
          <span className="verify-step-num">2</span>
          Upload Aadhar or PAN card
        </h2>

        {!idFile && (
          <label className="verify-upload-box">
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp,application/pdf"
              onChange={handleIdFileChange}
              className="verify-file-input"
            />
            <span className="verify-upload-text">
              Click to upload your Aadhar or PAN card
            </span>
            <span className="verify-upload-hint">
              JPG, PNG, or PDF · Max 5 MB
            </span>
          </label>
        )}

        {idFile && (
          <div className="verify-id-preview">
            {idPreviewUrl ? (
              <img
                src={idPreviewUrl}
                alt="ID document preview"
                className="verify-id-preview-img"
              />
            ) : (
              <div className="verify-id-preview-file">
                📄 {idFile.name}
              </div>
            )}

            <button
              type="button"
              className="btn-secondary"
              onClick={removeIdFile}
            >
              Remove & upload another
            </button>
          </div>
        )}

        {idError && <p className="form-error">{idError}</p>}
      </div>

      {/* ========================================================
          START ASSESSMENT
      ======================================================== */}

      {startError && <p className="form-error">{startError}</p>}

      <button
        type="button"
        className="btn-primary btn-block verify-start-btn"
        onClick={handleStartAssessment}
        disabled={!readyToStart || starting}
      >
        {starting
          ? "Starting assessment..."
          : "Start assessment"}
      </button>

      {!readyToStart && (
        <p className="verify-gate-hint">
          Complete both steps above to continue.
        </p>
      )}
    </div>
  );
}
