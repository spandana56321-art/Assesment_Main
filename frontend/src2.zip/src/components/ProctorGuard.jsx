import { useEffect, useRef, useState } from "react";
import "../styles/ProctorGuard.css";

// ============================================================
// PROCTOR GUARD
// ============================================================
//
// Watches for two integrity signals while the candidate is
// taking the exam, similar to how real assessment platforms
// (HackerRank, Codility, etc.) do it:
//
//   1. Full-screen exit — candidate left full-screen mode
//   2. Tab switch / window blur — candidate switched away from
//      this tab or minimized the window
//
// Each event is logged (via onViolation) and shown to the
// candidate as a visible warning with a running count, so they
// know they're being watched and can self-correct. This
// component does NOT auto-submit the exam on its own — that
// decision is left to the parent via onViolation, since
// auto-submitting on the very first accidental Alt-Tab would be
// too aggressive without configuring a threshold first.
//
// NOTE: This only logs violations in the browser for now. To
// actually persist them for admin review, wire onViolation up
// to a backend endpoint (e.g. POST /api/exams/:examId/violation).
// ============================================================

export default function ProctorGuard({ onViolation }) {
  const [violations, setViolations] = useState([]);
  const [showWarning, setShowWarning] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(
    Boolean(document.fullscreenElement)
  );

  const warningTimeoutRef = useRef(null);

  // ============================================================
  // LOG A VIOLATION
  // ============================================================

  function logViolation(type, message) {
    const event = {
      type,
      message,
      at: new Date().toISOString(),
    };

    setViolations((prev) => {
      const next = [...prev, event];

      if (onViolation) {
        onViolation(event, next.length);
      }

      return next;
    });

    setShowWarning(true);

    if (warningTimeoutRef.current) {
      clearTimeout(warningTimeoutRef.current);
    }

    warningTimeoutRef.current = setTimeout(() => {
      setShowWarning(false);
    }, 6000);
  }

  // ============================================================
  // REQUEST FULL-SCREEN
  // ============================================================

  function enterFullscreen() {
    const el = document.documentElement;

    const request =
      el.requestFullscreen ||
      el.webkitRequestFullscreen ||
      el.msRequestFullscreen;

    if (request) {
      request.call(el).catch((err) => {
        console.warn("Could not enter full-screen:", err);
      });
    }
  }

  // ============================================================
  // WATCH FULL-SCREEN STATE
  // ============================================================

  useEffect(() => {
    function handleFullscreenChange() {
      const nowFullscreen = Boolean(document.fullscreenElement);
      setIsFullscreen(nowFullscreen);

      if (!nowFullscreen) {
        logViolation(
          "fullscreen-exit",
          "You exited full-screen mode."
        );
      }
    }

    document.addEventListener(
      "fullscreenchange",
      handleFullscreenChange
    );

    return () => {
      document.removeEventListener(
        "fullscreenchange",
        handleFullscreenChange
      );
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ============================================================
  // WATCH TAB VISIBILITY (SWITCHING TABS / MINIMIZING)
  // ============================================================

  useEffect(() => {
    function handleVisibilityChange() {
      if (document.hidden) {
        logViolation(
          "tab-switch",
          "You switched away from this tab."
        );
      }
    }

    document.addEventListener(
      "visibilitychange",
      handleVisibilityChange
    );

    return () => {
      document.removeEventListener(
        "visibilitychange",
        handleVisibilityChange
      );
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ============================================================
  // CLEANUP TIMEOUT ON UNMOUNT
  // ============================================================

  useEffect(() => {
    return () => {
      if (warningTimeoutRef.current) {
        clearTimeout(warningTimeoutRef.current);
      }
    };
  }, []);

  // ============================================================
  // UI
  // ============================================================

  return (
    <>
      {!isFullscreen && (
        <div className="proctor-fullscreen-prompt">
          <span>You're not in full-screen mode.</span>
          <button
            type="button"
            className="proctor-fullscreen-btn"
            onClick={enterFullscreen}
          >
            Enter full-screen
          </button>
        </div>
      )}

      {showWarning && violations.length > 0 && (
        <div className="proctor-warning" role="alert">
          <span className="proctor-warning-icon" aria-hidden="true">
            !
          </span>
          <span>
            {violations[violations.length - 1].message} This has been
            logged ({violations.length}{" "}
            {violations.length === 1 ? "notice" : "notices"} so far).
          </span>
        </div>
      )}
    </>
  );
}
