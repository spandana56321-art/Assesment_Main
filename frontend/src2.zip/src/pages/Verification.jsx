import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useUser } from "../context/UserContext";
import { api } from "../services/api";
import { attachVerificationToExam, saveVerificationDraft } from "../services/localMediaStore";
import "../styles/Verification.css";

const MAX_ID_FILE_SIZE = 5 * 1024 * 1024;

export default function Verification() {
  const { user, updateUser } = useUser();
  const navigate = useNavigate();
  const location = useLocation();
  const domain = location.state?.domain || null;

  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);

  const [cameraStatus, setCameraStatus] = useState("idle");
  const [cameraError, setCameraError] = useState("");
  const [photoDataUrl, setPhotoDataUrl] = useState(null);
  const [idFile, setIdFile] = useState(null);
  const [documentType, setDocumentType] = useState("aadhaar");
  const [idPreviewUrl, setIdPreviewUrl] = useState(null);
  const [idError, setIdError] = useState("");
  const [starting, setStarting] = useState(false);
  const [startError, setStartError] = useState("");

  useEffect(() => {
    if (!user?.token) {
      navigate("/", { replace: true });
      return;
    }
    if (!domain?._id) navigate("/domains", { replace: true });
  }, [domain, navigate, user?.token]);

  async function startCamera() {
    setCameraError("");
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraStatus("unsupported");
      return;
    }

    try {
      setCameraStatus("requesting");
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 720 }, height: { ideal: 480 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
      setCameraStatus("streaming");
    } catch (err) {
      setCameraStatus(err?.name === "NotAllowedError" ? "denied" : "error");
      setCameraError(err?.message || "Unable to access your camera.");
    }
  }

  function stopCamera() {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
  }

  useEffect(() => {
    if (domain?._id) startCamera();
    return () => stopCamera();
    // Camera intentionally starts once when this verification screen opens.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [domain?._id]);

  function capturePhoto() {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    const width = video.videoWidth || 720;
    const height = video.videoHeight || 480;
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(video, 0, 0, width, height);
    setPhotoDataUrl(canvas.toDataURL("image/jpeg", 0.9));
    stopCamera();
  }

  function retakePhoto() {
    setPhotoDataUrl(null);
    startCamera();
  }

  async function handleIdFileChange(event) {
    const file = event.target.files?.[0];
    setIdError("");
    setIdFile(null);
    setIdPreviewUrl(null);
    if (!file) return;

    const extension = file.name.toLowerCase().split(".").pop();
    const allowedTypes = new Set(["image/jpeg", "image/png", "image/webp", "application/pdf"]);
    const allowedExtensions = new Set(["jpg", "jpeg", "png", "webp", "pdf"]);

    if (!allowedTypes.has(file.type) || !allowedExtensions.has(extension)) {
      setIdError("Upload a JPG, PNG, WEBP or PDF identity document.");
      return;
    }
    if (!file.size || file.size > MAX_ID_FILE_SIZE) {
      setIdError(file.size ? "File is too large. Maximum size is 5 MB." : "The selected file is empty.");
      return;
    }

    if (file.type === "application/pdf") {
      const header = await file.slice(0, 5).text();
      if (header !== "%PDF-") {
        setIdError("This file is not a valid PDF.");
        return;
      }
    } else {
      try {
        const bitmap = await createImageBitmap(file);
        const valid = bitmap.width > 0 && bitmap.height > 0;
        bitmap.close();
        if (!valid) throw new Error("Invalid image");
      } catch {
        setIdError("The selected image could not be opened.");
        return;
      }
    }

    setIdFile(file);
    if (file.type !== "application/pdf") {
      const reader = new FileReader();
      reader.onload = () => setIdPreviewUrl(reader.result);
      reader.readAsDataURL(file);
    }
  }

  function removeIdFile() {
    setIdFile(null);
    setIdPreviewUrl(null);
    setIdError("");
  }

  async function handleStartAssessment() {
    if (starting || !photoDataUrl || !idFile || !domain?._id) return;

    const requestFs = document.documentElement.requestFullscreen;
    if (requestFs) requestFs.call(document.documentElement).catch(() => {});

    try {
      setStarting(true);
      setStartError("");

      // Media stays in this browser's IndexedDB. It is never uploaded to the backend.
      await saveVerificationDraft({ documentType, idFile, photoDataUrl });

      const exam = await api.startExam(domain._id, user.token);
      if (!exam?.success || !exam.examId || !Array.isArray(exam.questions) || !exam.startTime || !exam.durationMinutes) {
        throw new Error(exam?.message || "Invalid exam response from server.");
      }
      if (!exam.questions.length) throw new Error("No questions are available for this assessment.");

      const startTimeMs = new Date(exam.startTime).getTime();
      const durationMinutes = Number(exam.durationMinutes);
      if (Number.isNaN(startTimeMs) || !durationMinutes || durationMinutes <= 0) {
        throw new Error("Invalid assessment timing received from server.");
      }

      const totalMarks = exam.questions.reduce((total, question) => total + Number(question?.marks || 0), 0);
      try {
        await attachVerificationToExam(exam.examId);
      } catch (mediaError) {
        console.warn("Local verification storage failed:", mediaError);
      }

      updateUser({
        token: user.token,
        domain: domain._id,
        domainId: domain._id,
        selectedDomain: domain,
        examId: exam.examId,
        examStatus: exam.status || "in_progress",
        questions: exam.questions,
        durationMinutes,
        startTime: exam.startTime,
        testEndTime: startTimeMs + durationMinutes * 60 * 1000,
        score: 0,
        totalMarks,
        autoSubmitted: false,
        answers: {},
      });

      navigate("/quiz", { replace: true });
    } catch (err) {
      console.error("Start exam error:", err);
      setStartError(err?.message || "Unable to start the assessment.");
    } finally {
      setStarting(false);
    }
  }

  if (!user?.token || !domain?._id) return null;
  const readyToStart = Boolean(photoDataUrl && idFile);

  return (
    <div className="assessment-card verify-card">
      <div className="verify-intro">
        <div>
          <p className="eyebrow">Step 4 · Identity check</p>
          <h1>Quick verification before you begin</h1>
          <p className="subtitle">
            Complete the two checks below for the <strong>{domain.name}</strong> assessment. Your ID and captured photo are stored locally on this browser for admin review.
          </p>
        </div>
        <span className="verify-local-badge">Local media storage</span>
      </div>

      <div className="verify-trust-row">
        <span><strong>Camera check</strong><small>One photo is captured before the test starts.</small></span>
        <span><strong>ID document</strong><small>JPG, PNG, WEBP or PDF · maximum 5 MB.</small></span>
        <span><strong>Assessment camera</strong><small>Live self-view and recording start with the test.</small></span>
      </div>

      <section className="verify-section">
        <div className="verify-section-heading">
          <span className="verify-step-num">1</span>
          <div><h2>Capture your photo</h2><p>Center your face and make sure the lighting is clear.</p></div>
        </div>

        <div className="verify-camera-box">
          <video ref={videoRef} autoPlay playsInline muted className={`verify-video ${!photoDataUrl && cameraStatus === "streaming" ? "verify-video--visible" : ""}`} />
          {!photoDataUrl && cameraStatus === "requesting" && <p className="loading-text">Requesting camera access…</p>}
          {!photoDataUrl && cameraStatus === "denied" && <p className="form-error">Camera access was denied. Allow camera permission and try again.</p>}
          {!photoDataUrl && cameraStatus === "unsupported" && <p className="form-error">This browser does not support camera access.</p>}
          {!photoDataUrl && cameraStatus === "error" && <p className="form-error">{cameraError || "Unable to access your camera."}</p>}
          {photoDataUrl && <img src={photoDataUrl} alt="Captured candidate" className="verify-photo-preview" />}
        </div>
        <canvas ref={canvasRef} hidden />

        <div className="verify-camera-actions">
          {!photoDataUrl && cameraStatus === "streaming" && <button type="button" className="btn-primary" onClick={capturePhoto}>Capture photo</button>}
          {!photoDataUrl && ["denied", "error", "unsupported"].includes(cameraStatus) && <button type="button" className="btn-secondary" onClick={startCamera}>Try again</button>}
          {photoDataUrl && <button type="button" className="btn-secondary" onClick={retakePhoto}>Retake photo</button>}
        </div>
      </section>

      <section className="verify-section">
        <div className="verify-section-heading">
          <span className="verify-step-num">2</span>
          <div><h2>Upload your identity document</h2><p>Choose the document type and upload the original file.</p></div>
        </div>

        <div className="verify-document-type">
          <label htmlFor="documentType">Document type</label>
          <select id="documentType" value={documentType} onChange={(e) => setDocumentType(e.target.value)}>
            <option value="aadhaar">Aadhaar card</option>
            <option value="pan">PAN card</option>
          </select>
        </div>

        {!idFile && (
          <label className="verify-upload-box">
            <input type="file" accept=".jpg,.jpeg,.png,.webp,.pdf,image/jpeg,image/png,image/webp,application/pdf" onChange={handleIdFileChange} className="verify-file-input" />
            <span className="verify-upload-icon">↑</span>
            <span className="verify-upload-text">Choose identity document</span>
            <span className="verify-upload-hint">JPG, PNG, WEBP or PDF · Max 5 MB</span>
          </label>
        )}

        {idFile && (
          <div className="verify-id-preview">
            {idPreviewUrl ? <img src={idPreviewUrl} alt="ID document preview" className="verify-id-preview-img" /> : <div className="verify-id-preview-file"><span>PDF</span><div><strong>{idFile.name}</strong><small>{(idFile.size / 1024 / 1024).toFixed(2)} MB</small></div></div>}
            <button type="button" className="btn-secondary" onClick={removeIdFile}>Replace document</button>
          </div>
        )}
        {idError && <p className="form-error">{idError}</p>}
      </section>

      {startError && <p className="form-error">{startError}</p>}

      <button type="button" className="btn-primary btn-block verify-start-btn" onClick={handleStartAssessment} disabled={!readyToStart || starting}>
        {starting ? "Preparing assessment…" : "Start assessment"}
      </button>
      {!readyToStart && <p className="verify-gate-hint">Complete the photo and identity document steps to continue.</p>}
    </div>
  );
}
